import streamlit as st
from .admin_user import AdminUser
from .admin_konten import AdminKonten
from .admin_stegano import AdminStegano
from database.komentar import Komentar
import pandas as pd

contents = AdminKonten()
users = AdminUser()
stegano = AdminStegano()
komen_db = Komentar()

def show_admin_page(user):
    st.title("👑 Admin Dashboard")
    placeholder = st.empty()
    menu = st.sidebar.radio("Pilih menu:", ["📦 Data Konten", "👥 Data User", "🧩 Steganografi", "💬 Komentar"])

    if menu == "📦 Data Konten":
        placeholder.empty()
        tab_c1, tab_c2, tab_c3, tab_c4 = st.tabs(["Daftar Konten","Daftar Enkripsi","Tambah Buah","Edit Buah"])
        with placeholder.container() :
            with tab_c1 :
                st.header("📚 Daftar Konten Buah")
                contents.daftarbuah()
            with tab_c2 :
                st.header("📚 Daftar Konten Buah Enkripsi")
                contents.daftarbuahenkrip()
            with tab_c3 :
                st.header("🍎 Tambah Buah Baru")
                contents.tambah_buah()
            with tab_c4 :
                st.header("📝 Update Konten Buah")
                contents.editbuah()

    elif menu == "👥 Data User":
        tab_u1, tab_u2 = st.tabs(["User","Admin"])
        with placeholder.container():
            with tab_u1 :
                st.header("Daftar User")
                users.user()
            with tab_u2 :
                st.header("Daftar Admin")
                users.admin()

    elif menu == "🧩 Steganografi":
        tab_s1, tab_s2, tab_s3 = st.tabs(["Tambah Stegano","Daftar Stegano","Dekripsi Stegano"])
        with placeholder.container():
            with tab_s1 :
                st.header("🧩 Tambah Steganografi LSB Encoder")
                stegano.tambahstegano()
            with tab_s2 :
                st.header("🧩 Galeri Steganografi")
                stegano.tampilkanstegano()
            with tab_s3 :
                st.header("🧩 Dekripsi Steganografi")
                stegano.ambilpesan()
    
    elif menu == "💬 Komentar":
        st.header("Daftar Komentar")
        komentar = komen_db.get_all_komentar()
        df_komentar = pd.DataFrame(komentar)
        st.dataframe(df_komentar)

        st.header("Hapus Komentar")
        id_del = komen_db.get_id()  # asumsinya return list of ids
        if id_del:
            hapus_id = st.selectbox("Pilih ID admin untuk dihapus:", id_del)
            if st.button("🗑️ Hapus Komentar"):
                komen_db.hapus_komentar(hapus_id)
                st.warning(f"User dengan ID {hapus_id} dihapus.")
                st.rerun()
    
